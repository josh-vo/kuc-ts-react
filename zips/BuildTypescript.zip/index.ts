import {Attachment} from '../esm/js/index'
(function(){
    var button = new Attachment({
        
    });
})()
